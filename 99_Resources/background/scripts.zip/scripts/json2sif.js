let X2JS = require('x2js');
const fs = require("fs");
const js = fs.readFileSync(0, "utf-8");
var dot = require('dot-object');

var attrpaths = new Object;
attrpaths["SEAInfo"] = ["SEAInfo.RefId","SEAInfo.CSSOContact.Name.Type","SEAInfo.CSSOContact.Address.Type","SEAInfo.CSSOContact.Address.TypeCodeset","SEAInfo.CSSOContact.PhoneNumberList.PhoneNumber.SIF_Action","SEAInfo.CSSOContact.PhoneNumberList.PhoneNumber.Type","SEAInfo.CSSOContact.PhoneNumberList.PhoneNumber.TypeCodeset","SEAInfo.SEAContactList.SEAContact.ContactInfo.Name.Type","SEAInfo.SEAContactList.SEAContact.ContactInfo.Address.Type","SEAInfo.SEAContactList.SEAContact.ContactInfo.Address.TypeCodeset","SEAInfo.SEAContactList.SEAContact.ContactInfo.PhoneNumberList.PhoneNumber.SIF_Action","SEAInfo.SEAContactList.SEAContact.ContactInfo.PhoneNumberList.PhoneNumber.Type","SEAInfo.SEAContactList.SEAContact.ContactInfo.PhoneNumberList.PhoneNumber.TypeCodeset","SEAInfo.PhoneNumberList.PhoneNumber.SIF_Action","SEAInfo.PhoneNumberList.PhoneNumber.Type","SEAInfo.PhoneNumberList.PhoneNumber.TypeCodeset","SEAInfo.AddressList.Address.SIF_Action","SEAInfo.AddressList.Address.Type","SEAInfo.AddressList.Address.TypeCodeset"];
attrpaths["StudentLEARelationship"] = ["StudentLEARelationship.RefId","StudentLEARelationship.StudentPersonalRefId","StudentLEARelationship.LEAInfoRefId","StudentLEARelationship.SchoolYear"];
attrpaths["SEAAccountability"] = ["SEAAccountability.RefId","SEAAccountability.SEAInfoRefId"];
attrpaths["SEAFederalFund"] = ["SEAFederalFund.RefId","SEAFederalFund.SEAInfoRefId"];
attrpaths["xCalendar"] = ["xCalendar.refId"];
attrpaths["xContact"] = ["xContact.refId"];
attrpaths["xCourse"] = ["xCourse.refId"];
attrpaths["xIndividualizedEducationPlan"] = ["xIndividualizedEducationPlan.refId"];
attrpaths["xLea"] = ["xLea.refId"];
attrpaths["xRoster"] = ["xRoster.refId"];
attrpaths["xSchool"] = ["xSchool.refId"];
attrpaths["xStaff"] = ["xStaff.refId"];
attrpaths["xStudent"] = ["xStudent.refId"];
attrpaths["xTransferIep"] = ["xTransferIep.refId","xTransferIep.iep.refId"];
attrpaths["AggregateStatisticInfo"] = ["AggregateStatisticInfo.RefId","AggregateStatisticInfo.Location.Type","AggregateStatisticInfo.Location.TypeCodeset"];
attrpaths["AggregateCharacteristicInfo"] = ["AggregateCharacteristicInfo.RefId"];
attrpaths["AggregateStatisticFact"] = ["AggregateStatisticFact.RefId"];
attrpaths["StudentMeal"] = ["StudentMeal.RefId","StudentMeal.StudentPersonalRefId","StudentMeal.MealStatus.Type","StudentMeal.MealStatus.TypeCodeset","StudentMeal.HistoricalMealStatus.MealStatus.Type","StudentMeal.HistoricalMealStatus.MealStatus.TypeCodeset"];
attrpaths["FoodserviceItem"] = ["FoodserviceItem.RefId"];
attrpaths["FoodserviceItemUnit"] = ["FoodserviceItemUnit.RefId"];
attrpaths["FoodserviceItemPortion"] = ["FoodserviceItemPortion.RefId"];
attrpaths["FoodserviceReimbursementRates"] = ["FoodserviceReimbursementRates.RefId","FoodserviceReimbursementRates.Agencies.Agency.Type","FoodserviceReimbursementRates.Agencies.Agency.TypeCodeset","FoodserviceReimbursementRates.Agencies.Agency.Rates.Rate.SevereNeed","FoodserviceReimbursementRates.Agencies.Agency.Rates.Rate.SevereNeedCodeset","FoodserviceReimbursementRates.Agencies.Agency.Rates.Rate.MealStatus.Type","FoodserviceReimbursementRates.Agencies.Agency.Rates.Rate.MealStatus.TypeCodeset"];
attrpaths["FoodserviceMealPrices"] = ["FoodserviceMealPrices.RefId","FoodserviceMealPrices.Prices.Price.MealStatus.Type","FoodserviceMealPrices.Prices.Price.MealStatus.TypeCodeset"];
attrpaths["StaffMeal"] = ["StaffMeal.RefId","StaffMeal.StaffPersonalRefId","StaffMeal.EarnedStatus.Type","StaffMeal.EarnedStatus.TypeCodeset"];
attrpaths["FoodserviceTransaction"] = ["FoodserviceTransaction.RefId","FoodserviceTransaction.Customer.SIF_RefId","FoodserviceTransaction.Customer.SIF_RefObject","FoodserviceTransaction.Customer.MealStatus.Type","FoodserviceTransaction.Customer.MealStatus.TypeCodeset","FoodserviceTransaction.Customer.EarnedStatus.Type","FoodserviceTransaction.Customer.EarnedStatus.TypeCodeset"];
attrpaths["FoodserviceTransactionDetails"] = ["FoodserviceTransactionDetails.RefId"];
attrpaths["FoodserviceTransactionPayMethod"] = ["FoodserviceTransactionPayMethod.RefId","FoodserviceTransactionPayMethod.TransactionPayMethods.TransactionPayMethod.Type","FoodserviceTransactionPayMethod.TransactionPayMethods.TransactionPayMethod.TypeCodeset"];
attrpaths["FoodserviceSales"] = ["FoodserviceSales.RefId"];
attrpaths["FoodserviceItemSales"] = ["FoodserviceItemSales.RefId","FoodserviceItemSales.ItemQuantities.ItemQuantity.FoodserviceItemPortionRefId"];
attrpaths["FoodserviceMenuPlan"] = ["FoodserviceMenuPlan.RefId"];
attrpaths["FoodserviceMilkSales"] = ["FoodserviceMilkSales.RefId","FoodserviceMilkSales.SaleQuantities.SaleQuantity.MealStatus.Type","FoodserviceMilkSales.SaleQuantities.SaleQuantity.MealStatus.TypeCodeset"];
attrpaths["FoodservicePurchaseTransaction"] = ["FoodservicePurchaseTransaction.RefId","FoodservicePurchaseTransaction.PurchaseQuantities.PurchaseQuantity.FoodserviceItemPortionRefId","FoodservicePurchaseTransaction.PurchaseQuantities.PurchaseQuantity.Earned","FoodservicePurchaseTransaction.PurchaseQuantities.PurchaseQuantity.EarnedCodeset"];
attrpaths["FoodserviceStaffEnrollmentCount"] = ["FoodserviceStaffEnrollmentCount.RefId","FoodserviceStaffEnrollmentCount.SchoolInfoRefId","FoodserviceStaffEnrollmentCount.Date","FoodserviceStaffEnrollmentCount.Counts.Count.MealStatus.Type","FoodserviceStaffEnrollmentCount.Counts.Count.MealStatus.TypeCodeset","FoodserviceStaffEnrollmentCount.Counts.Count.EarnedStatus.Type","FoodserviceStaffEnrollmentCount.Counts.Count.EarnedStatus.TypeCodeset"];
attrpaths["FoodserviceStaffMealCounts"] = ["FoodserviceStaffMealCounts.RefId","FoodserviceStaffMealCounts.Counts.Count.MealStatus.Type","FoodserviceStaffMealCounts.Counts.Count.MealStatus.TypeCodeset","FoodserviceStaffMealCounts.Counts.Count.EarnedStatus.Type","FoodserviceStaffMealCounts.Counts.Count.EarnedStatus.TypeCodeset"];
attrpaths["FoodserviceStudentEnrollmentCount"] = ["FoodserviceStudentEnrollmentCount.RefId","FoodserviceStudentEnrollmentCount.SchoolInfoRefId","FoodserviceStudentEnrollmentCount.Date","FoodserviceStudentEnrollmentCount.Counts.Count.MealStatus.Type","FoodserviceStudentEnrollmentCount.Counts.Count.MealStatus.TypeCodeset","FoodserviceStudentEnrollmentCount.Counts.Count.EarnedStatus.Type","FoodserviceStudentEnrollmentCount.Counts.Count.EarnedStatus.TypeCodeset"];
attrpaths["FoodserviceStudentMealCounts"] = ["FoodserviceStudentMealCounts.RefId","FoodserviceStudentMealCounts.Counts.Count.MealStatus.Type","FoodserviceStudentMealCounts.Counts.Count.MealStatus.TypeCodeset","FoodserviceStudentMealCounts.Counts.Count.EarnedStatus.Type","FoodserviceStudentMealCounts.Counts.Count.EarnedStatus.TypeCodeset"];
attrpaths["StudentRecordExchange"] = ["StudentRecordExchange.RefId"];
attrpaths["StudentDemographicRecord"] = ["StudentDemographicRecord.RefId","StudentDemographicRecord.SIF_RefId","StudentDemographicRecord.SIF_RefObject","StudentDemographicRecord.SIF_RefObjectCodeset","StudentDemographicRecord.StudentPersonalData.Name.Type","StudentDemographicRecord.StudentPersonalData.Name.TypeCodeset","StudentDemographicRecord.StudentPersonalData.OtherNames.Name.SIF_Action","StudentDemographicRecord.StudentPersonalData.OtherNames.Name.Type","StudentDemographicRecord.StudentPersonalData.OtherNames.Name.TypeCodeset","StudentDemographicRecord.StudentPersonalData.AddressList.Address.SIF_Action","StudentDemographicRecord.StudentPersonalData.AddressList.Address.Type","StudentDemographicRecord.StudentPersonalData.AddressList.Address.TypeCodeset","StudentDemographicRecord.StudentPersonalData.PhoneNumberList.PhoneNumber.SIF_Action","StudentDemographicRecord.StudentPersonalData.PhoneNumberList.PhoneNumber.Type","StudentDemographicRecord.StudentPersonalData.PhoneNumberList.PhoneNumber.TypeCodeset","StudentDemographicRecord.StudentContactsSummary.ParentGuardian1.Name.Type","StudentDemographicRecord.StudentContactsSummary.ParentGuardian1.PhoneNumberList.PhoneNumber.SIF_Action","StudentDemographicRecord.StudentContactsSummary.ParentGuardian1.PhoneNumberList.PhoneNumber.Type","StudentDemographicRecord.StudentContactsSummary.ParentGuardian1.PhoneNumberList.PhoneNumber.TypeCodeset","StudentDemographicRecord.StudentContactsSummary.ParentGuardian1.AddressList.Address.SIF_Action","StudentDemographicRecord.StudentContactsSummary.ParentGuardian1.AddressList.Address.Type","StudentDemographicRecord.StudentContactsSummary.ParentGuardian1.AddressList.Address.TypeCodeset","StudentDemographicRecord.StudentContactsSummary.ParentGuardian2.Name.Type","StudentDemographicRecord.StudentContactsSummary.ParentGuardian2.PhoneNumberList.PhoneNumber.SIF_Action","StudentDemographicRecord.StudentContactsSummary.ParentGuardian2.PhoneNumberList.PhoneNumber.Type","StudentDemographicRecord.StudentContactsSummary.ParentGuardian2.PhoneNumberList.PhoneNumber.TypeCodeset","StudentDemographicRecord.StudentContactsSummary.ParentGuardian2.AddressList.Address.SIF_Action","StudentDemographicRecord.StudentContactsSummary.ParentGuardian2.AddressList.Address.Type","StudentDemographicRecord.StudentContactsSummary.ParentGuardian2.AddressList.Address.TypeCodeset"];
attrpaths["StudentAcademicRecord"] = ["StudentAcademicRecord.RefId","StudentAcademicRecord.SIF_RefId","StudentAcademicRecord.SIF_RefObject","StudentAcademicRecord.SIF_RefObjectCodeset","StudentAcademicRecord.StudentSchoolEnrollmentData.SchoolAttendedRefId","StudentAcademicRecord.StudentSchoolEnrollmentData.Advisor.StaffPersonalData.Name.Type","StudentAcademicRecord.StudentSchoolEnrollmentData.Advisor.StaffPersonalData.AddressList.Address.SIF_Action","StudentAcademicRecord.StudentSchoolEnrollmentData.Advisor.StaffPersonalData.AddressList.Address.Type","StudentAcademicRecord.StudentSchoolEnrollmentData.Advisor.StaffPersonalData.AddressList.Address.TypeCodeset","StudentAcademicRecord.StudentSchoolEnrollmentData.Advisor.StaffPersonalData.PhoneNumberList.PhoneNumber.SIF_Action","StudentAcademicRecord.StudentSchoolEnrollmentData.Advisor.StaffPersonalData.PhoneNumberList.PhoneNumber.Type","StudentAcademicRecord.StudentSchoolEnrollmentData.Advisor.StaffPersonalData.PhoneNumberList.PhoneNumber.TypeCodeset","StudentAcademicRecord.StudentSchoolEnrollmentData.Counselor.StaffPersonalData.Name.Type","StudentAcademicRecord.StudentSchoolEnrollmentData.Counselor.StaffPersonalData.AddressList.Address.SIF_Action","StudentAcademicRecord.StudentSchoolEnrollmentData.Counselor.StaffPersonalData.AddressList.Address.Type","StudentAcademicRecord.StudentSchoolEnrollmentData.Counselor.StaffPersonalData.AddressList.Address.TypeCodeset","StudentAcademicRecord.StudentSchoolEnrollmentData.Counselor.StaffPersonalData.PhoneNumberList.PhoneNumber.SIF_Action","StudentAcademicRecord.StudentSchoolEnrollmentData.Counselor.StaffPersonalData.PhoneNumberList.PhoneNumber.Type","StudentAcademicRecord.StudentSchoolEnrollmentData.Counselor.StaffPersonalData.PhoneNumberList.PhoneNumber.TypeCodeset","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.RefId","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.Name.Type","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.Address.Type","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.Address.TypeCodeset","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.PhoneNumberList.PhoneNumber.SIF_Action","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.PhoneNumberList.PhoneNumber.Type","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.PhoneNumberList.PhoneNumber.TypeCodeset","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.AddressList.Address.SIF_Action","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.AddressList.Address.Type","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.AddressList.Address.TypeCodeset","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.PhoneNumberList.PhoneNumber.SIF_Action","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.PhoneNumberList.PhoneNumber.Type","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.SchoolInfoData.PhoneNumberList.PhoneNumber.TypeCodeset","StudentAcademicRecord.SchoolAttendanceHistory.SchoolAttended.MarkingSystems.MarkValueInfoData.RefId","StudentAcademicRecord.EnrollmentHistory.StudentSchoolEnrollmentData.SchoolAttendedRefId","StudentAcademicRecord.CurrentCourseActivity.TermInfoData.SchoolAttendedRefId","StudentAcademicRecord.CurrentCourseActivity.Courses.Course.MarkingPeriod.MarkData.MarkValueInfoDataRefId","StudentAcademicRecord.CourseHistory.Term.TermInfoData.SchoolAttendedRefId","StudentAcademicRecord.CourseHistory.Term.Courses.Course.MarkingPeriods.MarkingPeriod.MarkData.MarkValueInfoDataRefId"];
attrpaths["StudentSpecialEducationRecord"] = ["StudentSpecialEducationRecord.RefId","StudentSpecialEducationRecord.SIF_RefId","StudentSpecialEducationRecord.SIF_RefObject","StudentSpecialEducationRecord.SIF_RefObjectCodeset","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.Name.Type","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.Address.Type","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.Address.TypeCodeset","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.PhoneNumberList.PhoneNumber.SIF_Action","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.PhoneNumberList.PhoneNumber.Type","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.SchoolContactList.SchoolContact.ContactInfo.PhoneNumberList.PhoneNumber.TypeCodeset","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.AddressList.Address.SIF_Action","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.AddressList.Address.Type","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.AddressList.Address.TypeCodeset","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.PhoneNumberList.PhoneNumber.SIF_Action","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.PhoneNumberList.PhoneNumber.Type","StudentSpecialEducationRecord.StudentParticipationData.SchoolInfoData.PhoneNumberList.PhoneNumber.TypeCodeset"];
attrpaths["MarkValueInfo"] = ["MarkValueInfo.RefId","MarkValueInfo.SchoolInfoRefId","MarkValueInfo.Percentage.IsAccepted","MarkValueInfo.Numeric.IsAccepted","MarkValueInfo.Letter.IsAccepted","MarkValueInfo.Letter.ValidMark.SIF_Action","MarkValueInfo.Narrative.IsAccepted"];
attrpaths["MarkInfo"] = ["MarkInfo.RefId","MarkInfo.MarkValueInfoRefId","MarkInfo.SchoolInfoRefId"];
attrpaths["SectionMarkInfo"] = ["SectionMarkInfo.RefId","SectionMarkInfo.SectionInfoRefId","SectionMarkInfo.SchoolInfoRefId","SectionMarkInfo.TermMarkLists.MarkInfoList.TermInfoRefId","SectionMarkInfo.TermMarkLists.MarkInfoList.SIF_Action"];
attrpaths["StudentSectionMarks"] = ["StudentSectionMarks.RefId","StudentSectionMarks.StudentPersonalRefId","StudentSectionMarks.SectionInfoRefId","StudentSectionMarks.TermInfoRefId","StudentSectionMarks.SchoolInfoRefId","StudentSectionMarks.MarkList.Mark.MarkInfoRefId"];
attrpaths["GradingCategory"] = ["GradingCategory.RefId","GradingCategory.SectionInfoRefId","GradingCategory.TermInfoRefId","GradingCategory.SchoolInfoRefId"];
attrpaths["GradingAssignment"] = ["GradingAssignment.RefId","GradingAssignment.SectionInfoRefId","GradingAssignment.TermInfoRefId","GradingAssignment.SchoolInfoRefId","GradingAssignment.GradingCategoryRefId"];
attrpaths["GradingAssignmentScore"] = ["GradingAssignmentScore.RefId","GradingAssignmentScore.StudentPersonalRefId","GradingAssignmentScore.SectionInfoRefId","GradingAssignmentScore.SchoolInfoRefId","GradingAssignmentScore.GradingAssignmentRefId"];
attrpaths["StudentPeriodAttendance"] = ["StudentPeriodAttendance.RefId","StudentPeriodAttendance.StudentPersonalRefId","StudentPeriodAttendance.SectionInfoRefId","StudentPeriodAttendance.SchoolInfoRefId","StudentPeriodAttendance.Date","StudentPeriodAttendance.AuditInfo.CreationUser.Type","StudentPeriodAttendance.AuditInfo.CreationUser.TypeCodeset"];
attrpaths["StudentGrade"] = ["StudentGrade.RefId"];
attrpaths["Billing"] = ["Billing.RefId"];
attrpaths["Payment"] = ["Payment.RefId","Payment.BillingRefId"];
attrpaths["EmployeeAssignment"] = ["EmployeeAssignment.RefId","EmployeeAssignment.EmployeePersonalRefId"];
attrpaths["EmployeeContract"] = ["EmployeeContract.RefId","EmployeeContract.EmployeePersonalRefId"];
attrpaths["EmploymentRecord"] = ["EmploymentRecord.RefId","EmploymentRecord.SIF_RefId","EmploymentRecord.SIF_RefObject","EmploymentRecord.SIF_RefObjectCodeset"];
attrpaths["EmployeePersonal"] = ["EmployeePersonal.RefId","EmployeePersonal.Name.Type","EmployeePersonal.Name.TypeCodeset","EmployeePersonal.AddressList.Address.SIF_Action","EmployeePersonal.AddressList.Address.Type","EmployeePersonal.AddressList.Address.TypeCodeset","EmployeePersonal.PhoneNumberList.PhoneNumber.SIF_Action","EmployeePersonal.PhoneNumberList.PhoneNumber.Type","EmployeePersonal.PhoneNumberList.PhoneNumber.TypeCodeset"];
attrpaths["EmployeePicture"] = ["EmployeePicture.RefId","EmployeePicture.EmployeePersonalRefId"];
attrpaths["FinancialAnnual"] = ["FinancialAnnual.RefId"];
attrpaths["FinancialBudget"] = ["FinancialBudget.RefId"];
attrpaths["TimeWorked"] = ["TimeWorked.RefId"];
attrpaths["VendorInfo"] = ["VendorInfo.RefId","VendorInfo.ContactInfo.Name.Type","VendorInfo.ContactInfo.Address.Type","VendorInfo.ContactInfo.Address.TypeCodeset","VendorInfo.ContactInfo.PhoneNumberList.PhoneNumber.SIF_Action","VendorInfo.ContactInfo.PhoneNumberList.PhoneNumber.Type","VendorInfo.ContactInfo.PhoneNumberList.PhoneNumber.TypeCodeset"];
attrpaths["W4"] = ["W4.RefId","W4.EmployeePersonalRefId"];
attrpaths["EmployeeWage"] = ["EmployeeWage.RefId","EmployeeWage.EmployeePersonalRefId","EmployeeWage.PayRates.PayRate.Type","EmployeeWage.PayRates.PayRate.TypeCodeset"];
attrpaths["LocationInfo"] = ["LocationInfo.RefId","LocationInfo.LocationType","LocationInfo.LocationTypeCodeset","LocationInfo.AddressList.Address.SIF_Action","LocationInfo.AddressList.Address.Type","LocationInfo.AddressList.Address.TypeCodeset","LocationInfo.PhoneNumberList.PhoneNumber.SIF_Action","LocationInfo.PhoneNumberList.PhoneNumber.Type","LocationInfo.PhoneNumberList.PhoneNumber.TypeCodeset"];
attrpaths["Purchasing"] = ["Purchasing.RefId"];
attrpaths["AccountingPeriod"] = ["AccountingPeriod.RefId"];
attrpaths["FinancialAccount"] = ["FinancialAccount.RefId"];
attrpaths["FinancialAccountAccountingPeriodLocationInfo"] = ["FinancialAccountAccountingPeriodLocationInfo.RefId"];
attrpaths["FinancialClass"] = ["FinancialClass.RefId"];
attrpaths["FinancialIncomeStatement"] = ["FinancialIncomeStatement.RefId"];
attrpaths["FinancialTransaction"] = ["FinancialTransaction.RefId"];
attrpaths["FiscalYear"] = ["FiscalYear.RefId"];
attrpaths["ActivityProvider"] = ["ActivityProvider.RefId","ActivityProvider.Address.Type","ActivityProvider.Address.TypeCodeset"];
attrpaths["EmployeeCredit"] = ["EmployeeCredit.RefId","EmployeeCredit.EmployeePersonalRefId","EmployeeCredit.ProfessionalDevelopmentActivitiesRefId"];
attrpaths["EmployeeRecertification"] = ["EmployeeRecertification.RefId","EmployeeRecertification.Name.Type"];
attrpaths["EmployeeCredential"] = ["EmployeeCredential.RefId","EmployeeCredential.Name.Type"];
attrpaths["ProfessionalDevelopmentActivities"] = ["ProfessionalDevelopmentActivities.RefId","ProfessionalDevelopmentActivities.ActivityProviderRefId"];
attrpaths["ProfessionalDevelopmentProgram"] = ["ProfessionalDevelopmentProgram.RefId"];
attrpaths["ProfessionalDevelopmentRegistration"] = ["ProfessionalDevelopmentRegistration.RefId","ProfessionalDevelopmentRegistration.EmployeePersonalRefId"];
attrpaths["StudentParticipation"] = ["StudentParticipation.RefId","StudentParticipation.StudentPersonalRefId"];
attrpaths["StudentPlacement"] = ["StudentPlacement.RefId","StudentPlacement.StudentParticipationRefId","StudentPlacement.StudentPersonalRefId"];
attrpaths["TestAccommodation"] = ["TestAccommodation.RefId"];
attrpaths["StudentSpecialEducationSummary"] = ["StudentSpecialEducationSummary.RefId","StudentSpecialEducationSummary.StudentPersonalRefId","StudentSpecialEducationSummary.SummaryDate","StudentSpecialEducationSummary.SchoolYear"];
attrpaths["StudentCareerTechnical"] = ["StudentCareerTechnical.RefId","StudentCareerTechnical.StudentPersonalRefId"];
attrpaths["Assessment"] = ["Assessment.RefId"];
attrpaths["AssessmentItem"] = ["AssessmentItem.RefId","AssessmentItem.AssessmentFormRefId","AssessmentItem.ResponseType","AssessmentItem.ResponseTypeCodeset","AssessmentItem.Stimulus.Reference.MIMEType","AssessmentItem.Stimulus.Reference.Description","AssessmentItem.Stem.Reference.MIMEType","AssessmentItem.Stem.Reference.Description","AssessmentItem.ResponseChoices.Choice.ChoiceContent.Reference.MIMEType","AssessmentItem.ResponseChoices.Choice.ChoiceContent.Reference.Description","AssessmentItem.PerformanceLevels.PerformanceLevel.LevelName","AssessmentItem.PerformanceLevels.PerformanceLevel.LevelIdentifier","AssessmentItem.PerformanceLevels.PerformanceLevel.CutScores.ScoreMetric","AssessmentItem.PerformanceLevels.PerformanceLevel.CutScores.ScoreMetricCodeset"];
attrpaths["ItemCharacteristics"] = ["ItemCharacteristics.RefId","ItemCharacteristics.AssessmentItemRefId","ItemCharacteristics.AssessmentFormRefId","ItemCharacteristics.Measurements.Measurement.MeasurementCode","ItemCharacteristics.Measurements.Measurement.MeasurementCodeCodeset"];
attrpaths["AssessmentSubTest"] = ["AssessmentSubTest.RefId","AssessmentSubTest.ScoreRange.ScoreMetric","AssessmentSubTest.ScoreRange.ScoreMetricCodeset","AssessmentSubTest.PerformanceLevels.PerformanceLevel.LevelName","AssessmentSubTest.PerformanceLevels.PerformanceLevel.LevelIdentifier","AssessmentSubTest.PerformanceLevels.PerformanceLevel.CutScores.ScoreMetric","AssessmentSubTest.PerformanceLevels.PerformanceLevel.CutScores.ScoreMetricCodeset"];
attrpaths["AssessmentAdministration"] = ["AssessmentAdministration.RefId","AssessmentAdministration.AssessmentFormRefId","AssessmentAdministration.Address.Type","AssessmentAdministration.Address.TypeCodeset"];
attrpaths["AssessmentForm"] = ["AssessmentForm.RefId","AssessmentForm.AssessmentRefId"];
attrpaths["AssessmentRegistration"] = ["AssessmentRegistration.RefId","AssessmentRegistration.StudentPersonalRefId","AssessmentRegistration.AssessmentAdministrationRefId"];
attrpaths["StudentResponseSet"] = ["StudentResponseSet.RefId","StudentResponseSet.AssessmentAdministrationRefId","StudentResponseSet.StudentPersonalRefId","StudentResponseSet.AssessmentRegistrationRefId","StudentResponseSet.Items.Item.AssessmentItemRefId"];
attrpaths["StudentScoreSet"] = ["StudentScoreSet.RefId","StudentScoreSet.ScoreMetric","StudentScoreSet.ScoreMetricCodeset","StudentScoreSet.AssessmentAdministrationRefId","StudentScoreSet.StudentPersonalRefId","StudentScoreSet.AssessmentRegistrationRefId","StudentScoreSet.Scores.Score.AssessmentSubTestRefId"];
attrpaths["AssessmentPackage"] = ["AssessmentPackage.RefId"];
attrpaths["LearningStandardDocument"] = ["LearningStandardDocument.RefId"];
attrpaths["LearningStandardItem"] = ["LearningStandardItem.RefId"];
attrpaths["CurriculumStructure"] = ["CurriculumStructure.RefId"];
attrpaths["Lesson"] = ["Lesson.RefId","Lesson.LessonSources.LessonSource.Author.Name.Type","Lesson.LessonSources.LessonSource.Author.Address.Type","Lesson.LessonSources.LessonSource.Author.Address.TypeCodeset"];
attrpaths["Activity"] = ["Activity.RefId","Activity.Evaluation.EvaluationType","Activity.Evaluation.EvaluationTypeCodeset"];
attrpaths["Assignment"] = ["Assignment.RefId"];
attrpaths["LearningResource"] = ["LearningResource.RefId","LearningResource.Contacts.Contact.Name.Type","LearningResource.Contacts.Contact.Name.TypeCodeset","LearningResource.Contacts.Contact.Address.Type","LearningResource.Contacts.Contact.Address.TypeCodeset","LearningResource.Contacts.Contact.PhoneNumber.Type","LearningResource.Contacts.Contact.PhoneNumber.TypeCodeset","LearningResource.Evaluations.Evaluation.RefId","LearningResource.Evaluations.Evaluation.Name.Type"];
attrpaths["ContentCatalog"] = ["ContentCatalog.RefId"];
attrpaths["PersonRoleAssociation"] = ["PersonRoleAssociation.RefId"];
attrpaths["ResponseToIntervention"] = ["ResponseToIntervention.RefId","ResponseToIntervention.StudentPersonalRefId","ResponseToIntervention.SchoolInfoRefId","ResponseToIntervention.StaffPersonalRefId","ResponseToIntervention.StudentPlacementRefId","ResponseToIntervention.InterventionProviderNames.InterventionProviderName.StaffPersonalRefId"];
attrpaths["RTIResults"] = ["RTIResults.RefId","RTIResults.StudentPersonalRefId","RTIResults.StudentPlacementRefId","RTIResults.ResponseToInterventionRefId"];
attrpaths["LearningStandardAssociation"] = ["LearningStandardAssociation.RefId","LearningStandardAssociation.TargetObjects.TargetObject.ObjectType","LearningStandardAssociation.TargetObjects.TargetObject.ObjectTypeCodeset"];
attrpaths["LibraryPatronStatus"] = ["LibraryPatronStatus.RefId","LibraryPatronStatus.LibraryType","LibraryPatronStatus.SIF_RefId","LibraryPatronStatus.SIF_RefObject","LibraryPatronStatus.SIF_RefObjectCodeset","LibraryPatronStatus.TransactionList.Transaction.ItemInfo.Type","LibraryPatronStatus.TransactionList.Transaction.ItemInfo.TypeCodeset","LibraryPatronStatus.TransactionList.Transaction.FineInfoList.FineInfo.Type","LibraryPatronStatus.TransactionList.Transaction.FineInfoList.FineInfo.TypeCodeset","LibraryPatronStatus.TransactionList.Transaction.HoldInfoList.HoldInfo.Type","LibraryPatronStatus.TransactionList.Transaction.HoldInfoList.HoldInfo.TypeCodeset","LibraryPatronStatus.MessageList.Message.Priority","LibraryPatronStatus.MessageList.Message.PriorityCodeset"];
attrpaths["Address"] = ["Address.RefId"];
attrpaths["StudentProgramAssociation"] = ["StudentProgramAssociation.RefId","StudentProgramAssociation.FundingSourceList.FundingSource.Codeset"];
attrpaths["StudentActivityInfo"] = ["StudentActivityInfo.RefId","StudentActivityInfo.Location.Type","StudentActivityInfo.Location.TypeCodeset"];
attrpaths["StudentActivityParticipation"] = ["StudentActivityParticipation.RefId","StudentActivityParticipation.StudentPersonalRefId","StudentActivityParticipation.StudentActivityInfoRefId","StudentActivityParticipation.SchoolYear"];
attrpaths["DisciplineIncident"] = ["DisciplineIncident.RefId","DisciplineIncident.SchoolYear","DisciplineIncident.IncidentReporter.Type","DisciplineIncident.IncidentReporter.TypeCodeset","DisciplineIncident.IncidentReporter.Name.Type","DisciplineIncident.OffenderList.Offender.Type","DisciplineIncident.OffenderList.Offender.TypeCodeset","DisciplineIncident.OffenderList.Offender.Name.Type","DisciplineIncident.VictimList.Victim.Type","DisciplineIncident.VictimList.Victim.TypeCodeset","DisciplineIncident.VictimList.Victim.Name.Type"];
attrpaths["CalendarSummary"] = ["CalendarSummary.RefId","CalendarSummary.SchoolInfoRefId","CalendarSummary.SchoolYear"];
attrpaths["CalendarDate"] = ["CalendarDate.RefId","CalendarDate.Date","CalendarDate.CalendarSummaryRefId","CalendarDate.SchoolInfoRefId","CalendarDate.SchoolYear"];
attrpaths["StudentAttendanceSummary"] = ["StudentAttendanceSummary.RefId","StudentAttendanceSummary.StudentPersonalRefId","StudentAttendanceSummary.SchoolInfoRefId","StudentAttendanceSummary.SchoolYear"];
attrpaths["AttendanceCodeInfo"] = ["AttendanceCodeInfo.RefId","AttendanceCodeInfo.SchoolInfoRefId"];
attrpaths["RoomInfo"] = ["RoomInfo.RefId","RoomInfo.SchoolInfoRefId","RoomInfo.PhoneNumber.Type","RoomInfo.PhoneNumber.TypeCodeset"];
attrpaths["RoomType"] = ["RoomType.RefId","RoomType.SchoolInfoRefId"];
attrpaths["SchoolCourseInfo"] = ["SchoolCourseInfo.RefId","SchoolCourseInfo.SchoolInfoRefId","SchoolCourseInfo.SchoolYear"];
attrpaths["SchoolInfo"] = ["SchoolInfo.RefId","SchoolInfo.SchoolContactList.SchoolContact.ContactInfo.Name.Type","SchoolInfo.SchoolContactList.SchoolContact.ContactInfo.Address.Type","SchoolInfo.SchoolContactList.SchoolContact.ContactInfo.Address.TypeCodeset","SchoolInfo.SchoolContactList.SchoolContact.ContactInfo.PhoneNumberList.PhoneNumber.SIF_Action","SchoolInfo.SchoolContactList.SchoolContact.ContactInfo.PhoneNumberList.PhoneNumber.Type","SchoolInfo.SchoolContactList.SchoolContact.ContactInfo.PhoneNumberList.PhoneNumber.TypeCodeset","SchoolInfo.AddressList.Address.SIF_Action","SchoolInfo.AddressList.Address.Type","SchoolInfo.AddressList.Address.TypeCodeset","SchoolInfo.PhoneNumberList.PhoneNumber.SIF_Action","SchoolInfo.PhoneNumberList.PhoneNumber.Type","SchoolInfo.PhoneNumberList.PhoneNumber.TypeCodeset","SchoolInfo.SchoolCharter.Type","SchoolInfo.SchoolCharter.TypeCodeset"];
attrpaths["SectionInfo"] = ["SectionInfo.RefId","SectionInfo.SchoolCourseInfoRefId","SectionInfo.SchoolYear","SectionInfo.ScheduleInfoList.ScheduleInfo.TermInfoRefId","SectionInfo.SchoolCourseInfoOverride.Override","SectionInfo.SchoolCourseInfoOverride.OverrideCodeset"];
attrpaths["StaffPersonal"] = ["StaffPersonal.RefId","StaffPersonal.Name.Type","StaffPersonal.Name.TypeCodeset","StaffPersonal.OtherNames.Name.SIF_Action","StaffPersonal.OtherNames.Name.Type","StaffPersonal.OtherNames.Name.TypeCodeset","StaffPersonal.AddressList.Address.SIF_Action","StaffPersonal.AddressList.Address.Type","StaffPersonal.AddressList.Address.TypeCodeset","StaffPersonal.PhoneNumberList.PhoneNumber.SIF_Action","StaffPersonal.PhoneNumberList.PhoneNumber.Type","StaffPersonal.PhoneNumberList.PhoneNumber.TypeCodeset"];
attrpaths["StudentContact"] = ["StudentContact.RefId","StudentContact.StudentPersonalRefId","StudentContact.Name.Type","StudentContact.Name.TypeCodeset","StudentContact.OtherNames.Name.SIF_Action","StudentContact.OtherNames.Name.Type","StudentContact.OtherNames.Name.TypeCodeset","StudentContact.AddressList.Address.SIF_Action","StudentContact.AddressList.Address.Type","StudentContact.AddressList.Address.TypeCodeset","StudentContact.PhoneNumberList.PhoneNumber.SIF_Action","StudentContact.PhoneNumberList.PhoneNumber.Type","StudentContact.PhoneNumberList.PhoneNumber.TypeCodeset"];
attrpaths["StudentDailyAttendance"] = ["StudentDailyAttendance.RefId","StudentDailyAttendance.StudentPersonalRefId","StudentDailyAttendance.SchoolInfoRefId","StudentDailyAttendance.Date","StudentDailyAttendance.SchoolYear"];
attrpaths["StudentPersonal"] = ["StudentPersonal.RefId","StudentPersonal.Name.Type","StudentPersonal.Name.TypeCodeset","StudentPersonal.OtherNames.Name.SIF_Action","StudentPersonal.OtherNames.Name.Type","StudentPersonal.OtherNames.Name.TypeCodeset","StudentPersonal.AddressList.Address.SIF_Action","StudentPersonal.AddressList.Address.Type","StudentPersonal.AddressList.Address.TypeCodeset","StudentPersonal.PhoneNumberList.PhoneNumber.SIF_Action","StudentPersonal.PhoneNumberList.PhoneNumber.Type","StudentPersonal.PhoneNumberList.PhoneNumber.TypeCodeset"];
attrpaths["StudentPicture"] = ["StudentPicture.RefId","StudentPicture.StudentPersonalRefId","StudentPicture.SchoolYear"];
attrpaths["StudentSchoolEnrollment"] = ["StudentSchoolEnrollment.RefId","StudentSchoolEnrollment.StudentPersonalRefId","StudentSchoolEnrollment.SchoolInfoRefId","StudentSchoolEnrollment.MembershipType","StudentSchoolEnrollment.MembershipTypeCodeset","StudentSchoolEnrollment.TimeFrame","StudentSchoolEnrollment.TimeFrameCodeset","StudentSchoolEnrollment.SchoolYear"];
attrpaths["StudentSectionEnrollment"] = ["StudentSectionEnrollment.RefId","StudentSectionEnrollment.StudentPersonalRefId","StudentSectionEnrollment.SectionInfoRefId","StudentSectionEnrollment.SchoolYear","StudentSectionEnrollment.ScheduleInfoOverrideList.ScheduleInfoOverride.Override","StudentSectionEnrollment.ScheduleInfoOverrideList.ScheduleInfoOverride.OverrideCodeset","StudentSectionEnrollment.ScheduleInfoOverrideList.ScheduleInfoOverride.TermInfoRefId"];
attrpaths["TermInfo"] = ["TermInfo.RefId","TermInfo.SchoolInfoRefId","TermInfo.SchoolYear"];
attrpaths["StudentSnapshot"] = ["StudentSnapshot.RefId","StudentSnapshot.SnapDate","StudentSnapshot.StudentPersonalRefId","StudentSnapshot.SchoolYear","StudentSnapshot.Name.Type","StudentSnapshot.Address.Type","StudentSnapshot.Address.TypeCodeset"];
attrpaths["LEAInfo"] = ["LEAInfo.RefId","LEAInfo.LEAContactList.LEAContact.ContactInfo.Name.Type","LEAInfo.LEAContactList.LEAContact.ContactInfo.Address.Type","LEAInfo.LEAContactList.LEAContact.ContactInfo.Address.TypeCodeset","LEAInfo.LEAContactList.LEAContact.ContactInfo.PhoneNumberList.PhoneNumber.SIF_Action","LEAInfo.LEAContactList.LEAContact.ContactInfo.PhoneNumberList.PhoneNumber.Type","LEAInfo.LEAContactList.LEAContact.ContactInfo.PhoneNumberList.PhoneNumber.TypeCodeset","LEAInfo.PhoneNumberList.PhoneNumber.SIF_Action","LEAInfo.PhoneNumberList.PhoneNumber.Type","LEAInfo.PhoneNumberList.PhoneNumber.TypeCodeset","LEAInfo.AddressList.Address.SIF_Action","LEAInfo.AddressList.Address.Type","LEAInfo.AddressList.Address.TypeCodeset"];
attrpaths["StaffAssignment"] = ["StaffAssignment.RefId","StaffAssignment.SchoolInfoRefId","StaffAssignment.SchoolYear","StaffAssignment.StaffPersonalRefId"];
attrpaths["BellSchedule"] = ["BellSchedule.RefId"];
attrpaths["StudentContactPersonal"] = ["StudentContactPersonal.RefId","StudentContactPersonal.PersonInfo.Name.Type","StudentContactPersonal.PersonInfo.Name.TypeCodeset","StudentContactPersonal.PersonInfo.OtherNames.Name.SIF_Action","StudentContactPersonal.PersonInfo.OtherNames.Name.Type","StudentContactPersonal.PersonInfo.OtherNames.Name.TypeCodeset","StudentContactPersonal.PersonInfo.AddressList.Address.SIF_Action","StudentContactPersonal.PersonInfo.AddressList.Address.Type","StudentContactPersonal.PersonInfo.AddressList.Address.TypeCodeset","StudentContactPersonal.PersonInfo.PhoneNumberList.PhoneNumber.SIF_Action","StudentContactPersonal.PersonInfo.PhoneNumberList.PhoneNumber.Type","StudentContactPersonal.PersonInfo.PhoneNumberList.PhoneNumber.TypeCodeset"];
attrpaths["StudentContactRelationship"] = ["StudentContactRelationship.RefId","StudentContactRelationship.StudentPersonalRefId","StudentContactRelationship.StudentContactPersonalRefId"];
attrpaths["StaffSectionAssignment"] = ["StaffSectionAssignment.RefId"];
attrpaths["StaffEvaluation"] = ["StaffEvaluation.RefId"];
attrpaths["SectionCorrelation"] = ["SectionCorrelation.RefId"];
attrpaths["SchoolAccountability"] = ["SchoolAccountability.RefId","SchoolAccountability.SchoolInfoRefId"];
attrpaths["LEAAccountability"] = ["LEAAccountability.RefId","LEAAccountability.LEAInfoRefId"];
attrpaths["SchoolFederalFund"] = ["SchoolFederalFund.RefId","SchoolFederalFund.SchoolInfoRefId"];
attrpaths["LEAFederalFund"] = ["LEAFederalFund.RefId","LEAFederalFund.LEAInfoRefId"];
attrpaths["StudentMigrant"] = ["StudentMigrant.RefId","StudentMigrant.StudentInfoRefId"];
attrpaths["BusEquipment"] = ["BusEquipment.RefId"];
attrpaths["BusInfo"] = ["BusInfo.RefId"];
attrpaths["BusRouteDetail"] = ["BusRouteDetail.RefId","BusRouteDetail.BusRouteInfoRefId"];
attrpaths["BusRouteInfo"] = ["BusRouteInfo.RefId","BusRouteInfo.Name.Type"];
attrpaths["BusStopInfo"] = ["BusStopInfo.RefId"];
attrpaths["StudentTransportInfo"] = ["StudentTransportInfo.RefId","StudentTransportInfo.StudentPersonalRefId","StudentTransportInfo.Type","StudentTransportInfo.TypeCodeset","StudentTransportInfo.DayOfWeek","StudentTransportInfo.DayOfWeekCodeset","StudentTransportInfo.SchoolInfoRefId","StudentTransportInfo.OriginPoint.BusRouteDetailRefId","StudentTransportInfo.DestinationPoint.BusRouteDetailRefId"];
attrpaths["BusPositionInfo"] = ["BusPositionInfo.RefId","BusPositionInfo.BusDriver.Name.Type","BusPositionInfo.BusStaffList.BusStaff.Name.Type"];
attrpaths["Authentication"] = ["Authentication.RefId","Authentication.SIF_RefId","Authentication.SIF_RefObject","Authentication.SIF_RefObjectCodeset"];
attrpaths["EnergyUsage"] = ["EnergyUsage.RefId"];
attrpaths["IdMApplication"] = ["IdMApplication.RefId"];
attrpaths["IdMAuthentication"] = ["IdMAuthentication.RefId"];
attrpaths["IdMAuthorization"] = ["IdMAuthorization.RefId"];
attrpaths["UserOrganizationAssociation"] = ["UserOrganizationAssociation.RefId"];
attrpaths["PersonPrivacyObligationDocument"] = ["PersonPrivacyObligationDocument.RefId"];

/* this is inefficent */
function attributes(newobj) {
  var tgt = dot.dot(newobj); /* get all paths within the JSON object */
  var object = Object.keys(tgt)[0].replace(/\..*$/, ""); /* get name of object */
  for(var i=0; i< attrpaths[object].length; i++) {
      for (var key in tgt) {
      /* brute force lookup: compare all paths in the object to all 
        complex content attribute paths known for the object */
          var key_stripped;
          key_stripped = key.replace(/\.[0-9]+/g, "");
          /* we don't have wildcard array access (cf. doc-wild) + path rename command in the same JS library.
             So forced to generate paths stripped of array indexes,
             to match registered complex content attribute paths  */
          if(key_stripped == attrpaths[object][i]) {
              /* indicate to x2js that this is an XML attribute */
              dot.move(key, key.replace(/\.([^.]+)$/, "._$1"), newobj);
          }
      }
  }

    /* value key is used when there are attributes on simple content.
       Rearrange attributes if there is a value key */
    var paths = [];
    for (var key in tgt) {
        if(key.endsWith(".value")) {
            paths.push(key.replace(/\.value/, ""));
        }
    }
      for(var i=0; i<paths.length; i++) {
          for(var key in tgt) {
              if (key.startsWith(paths[i])) {
                  if (key == paths[i] + ".value") {
                     /* x2js counterpart to PESC JSON "value" key */
                      dot.move(key, paths[i] + ".__text", newobj);
                  } else if (!key.replace(paths[i] + ".", "").includes(".")) {
                     /* indicate in x2js that all sibling keys to "value" are XML attributes */
                    dot.move(key, key.replace(/\.([^.]+)$/, "._$1"), newobj);
                  }
              }
          }
      }
      return newobj;
}

var x = new X2JS({stripWhitespaces : false});
if(js !== null && js !== '') {
    var json = JSON.parse(js);
    /* presupposes we are processing array of JSON objects */
    for(var i=0; i<json.length; i++) {
        newobj = json[i];
        newobj = attributes(newobj);
        var xml = x.js2xml(newobj);
        console.log(xml);
    }
}
else {
  console.log("Warning:  'fs' not installed?")
}
